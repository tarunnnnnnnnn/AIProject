const apiKey = 'e214bb3ed35277ca1f8b044b233b7414';

const weatherForm = document.getElementById('weatherForm');
const cityInput = document.getElementById('cityInput');
const weatherResult = document.getElementById('weatherResult');
const loadingSpinner = document.getElementById('loadingSpinner');
const detectLocation = document.getElementById('detectLocation');
const speakButton = document.getElementById('speakButton');
const scrollSlider = document.getElementById('scrollSlider');

weatherForm.addEventListener('submit', function (e) {
  e.preventDefault();
  const city = cityInput.value.trim();
  if (city) {
    getWeatherByCity(city);
  } else {
    weatherResult.innerHTML = `<p style="color:red;">Please enter a city name.</p>`;
  }
});

detectLocation.addEventListener('click', () => {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(position => {
      const { latitude, longitude } = position.coords;
      getWeatherByCoords(latitude, longitude);
    }, (error) => {
      alert('Unable to get location: ' + error.message);
      console.error('Geolocation error:', error);
    });
  } else {
    alert('Geolocation not supported.');
  }
});

function getWeatherByCity(city) {
  weatherResult.innerHTML = '';
  loadingSpinner.style.display = 'block';
  speakButton.style.display = 'none';

  fetch(`https://api.openweathermap.org/data/2.5/forecast?q=${city}&units=metric&appid=${apiKey}`)
    .then(response => {
      if (!response.ok) {
        throw new Error(`Weather data for "${city}" not found.`);
      }
      return response.json();
    })
    .then(data => {
      showWeather(data);
    })
    .catch(error => {
      loadingSpinner.style.display = 'none';
      weatherResult.innerHTML = `<p style="color:red;">${error.message}</p>`;
    });
}

function getWeatherByCoords(lat, lon) {
  weatherResult.innerHTML = '';
  loadingSpinner.style.display = 'block';
  speakButton.style.display = 'none';

  fetch(`https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&units=metric&appid=${apiKey}`)
    .then(response => {
      if (!response.ok) {
        throw new Error('Unable to fetch weather data for your location.');
      }
      return response.json();
    })
    .then(data => {
      showWeather(data);
    })
    .catch(error => {
      loadingSpinner.style.display = 'none';
      weatherResult.innerHTML = `<p style="color:red;">${error.message}</p>`;
    });
}

function showWeather(data) {
  loadingSpinner.style.display = 'none';
  
  if (!data || !data.list || data.list.length === 0) {
    weatherResult.innerHTML = `<p style="color:red;">Weather data not available!</p>`;
    return;
  }

  const today = data.list[0];
  const tomorrow = data.list.length > 8 ? data.list[8] : data.list[data.list.length - 1];

  const aiSummary = generateAISummary(today, tomorrow);
  const iconUrl = today.weather && today.weather[0] ? `https://openweathermap.org/img/wn/${today.weather[0].icon}@2x.png` : '';

  weatherResult.innerHTML = `
    <h2>${data.city.name}, ${data.city.country}</h2>
    ${iconUrl ? `<img src="${iconUrl}" alt="${today.weather[0].description}">` : ''}
    <h3>${today.weather && today.weather[0] ? today.weather[0].description : 'No description available'}</h3>
    <p>Temperature: ${today.main.temp}°C</p>
    <p>Humidity: ${today.main.humidity}%</p>
    <p>Wind Speed: ${today.wind.speed} m/s</p>
    <hr>
    <h4>🤖 AI Forecast:</h4>
    <p id="aiSummary">${aiSummary}</p>
  `;

  speakButton.style.display = 'block';
}

function generateAISummary(today, tomorrow) {
  let summary = '';

  if (!today || !today.weather || !today.weather[0]) return "Weather data not available.";

  const todayMain = today.weather[0].main.toLowerCase();
  const tomorrowMain = (tomorrow && tomorrow.weather && tomorrow.weather[0])
    ? tomorrow.weather[0].main.toLowerCase()
    : todayMain;

  if (todayMain.includes('rain') || tomorrowMain.includes('rain')) {
    summary += "Rain expected. Carry an umbrella! ☔ ";
  } else if (todayMain.includes('clear') && tomorrowMain.includes('clear')) {
    summary += "Clear skies ahead! 🌞 ";
  } else if (todayMain.includes('snow')) {
    summary += "Snowfall possible. Stay warm! ❄️ ";
  } else {
    summary += "Mixed weather ahead. Stay prepared! 🌦️ ";
  }

  if (tomorrow && tomorrow.main && tomorrow.main.temp !== undefined) {
    if (tomorrow.main.temp > 30) {
      summary += " Very hot tomorrow. Stay hydrated! 🥵";
    } else if (tomorrow.main.temp < 10) {
      summary += " Cold weather expected. Bundle up! 🧥";
    }
  }

  return summary;
}

// Text-to-Speech
speakButton.addEventListener('click', () => {
  const summaryText = document.getElementById('aiSummary').innerText;
  const synth = window.speechSynthesis;
  const utterance = new SpeechSynthesisUtterance(summaryText);
  synth.speak(utterance);
});

// Scroll slider control
scrollSlider.addEventListener('input', function () {
  const scrollable = document.querySelector('.scrollable');
  const maxScroll = scrollable.scrollHeight - scrollable.clientHeight;
  scrollable.scrollTop = (scrollSlider.value / 100) * maxScroll;
});
